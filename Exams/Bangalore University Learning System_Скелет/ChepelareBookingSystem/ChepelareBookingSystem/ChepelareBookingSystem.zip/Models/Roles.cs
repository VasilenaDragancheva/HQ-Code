﻿namespace ChepelareBookingSystem.Models
{
    public enum Roles
    {
        User, 

        VenueAdmin
    }
}