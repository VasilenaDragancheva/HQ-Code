namespace ChepelareBookingSystem.Interfaces
{
    public interface IBookable
    {
        void GetBooked();
    }
}