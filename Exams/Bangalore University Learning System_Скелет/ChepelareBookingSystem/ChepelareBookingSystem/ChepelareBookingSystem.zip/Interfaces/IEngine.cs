namespace ChepelareBookingSystem.Interfaces
{
    public interface IEngine
    {
        void StartOperation();
    }
}