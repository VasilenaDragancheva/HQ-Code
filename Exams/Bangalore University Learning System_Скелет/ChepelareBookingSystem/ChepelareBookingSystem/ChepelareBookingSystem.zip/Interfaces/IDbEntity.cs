﻿namespace ChepelareBookingSystem.Interfaces
{
    public interface IDbEntity
    {
        int Id { get; set; }
    }
}

// Ever wondered about the difference between I...able and I...er? Here it is :)