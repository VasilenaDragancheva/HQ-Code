namespace ChepelareBookingSystem.Interfaces
{
    public interface IBooker
    {
        void Book(IBookable target);
    }
}