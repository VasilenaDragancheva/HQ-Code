﻿namespace BangaloreUniversityLearningSystem
{
    using BangaloreUniversityLearningSystem.Core;

    public class Program
    {
        public static void Main()
        {
            var engine = new BangaloreUniversityEngine();
            engine.Run();
        }
    }
}