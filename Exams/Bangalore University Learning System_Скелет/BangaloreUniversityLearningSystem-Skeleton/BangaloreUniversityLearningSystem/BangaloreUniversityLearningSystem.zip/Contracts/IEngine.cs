namespace BangaloreUniversityLearningSystem.Contracts
{
    public interface IEngine
    {
        void Run();
    }
}